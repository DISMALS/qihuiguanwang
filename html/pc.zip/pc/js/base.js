﻿(function ($) {
    var winH = $(window).height();
    var winW = $(window).width();
    var ltr = '<i class="ltr"></i>';
    var ttb = '<i class="ttb"></i>';
    var rtl = '<i class="rtl"></i>';
    var btt = '<i class="btt"></i>';

    //左侧导航栏高度获取
    function leftHeight() {
        var winH = $(window).height();
        var winW = $(window).width();
        var leftHeadH = $(".leftHead").height(winH);
        var leftHeadW = $(".leftHead").width();
        var logoH = $(".logo").height();
        $(".bor").height(winH - logoH);
        $(".rightMain").height(winH);
        $(".rightMain").width(winW - leftHeadW);
        $(".page").height(winH);
        if (winH < 730) {
            $(".mainMenu li").css("padding", "0.8em 0em");
        } else {
            $(".mainMenu li").css("padding", "1em 0em");
        }
    }
    leftHeight();

    //右侧子菜单
    $(".menu").click(function () {
        var this_ = $(this);
        this_.fadeOut();
        this_.siblings(".rightMenu").slideDown(1000, function () {
            $(this).children("li").click(function () {
                $(".rightMenu").slideUp();
                this_.fadeIn();
            });

        });
    });

    //鼠标滑过
    $(".mainMenu li").each(function (i, ele) {
        $(".mainMenu li").eq(i).children("a").bind({
            mouseenter: function () {
                var this_ = $(this);
                this_.append(ltr + ttb + rtl + btt); //向鼠标滑过的a内添加i标签
                if (this_.hasClass("act")) {
                    return false;
                } else {
                    this_.find(".ltr").css({
                        top: 0,
                        left: 0,
                        height: "1px"
                    }).stop().animate({
                        width: "100%"
                    }, 300);
                    this_.find(".ttb").css({
                        top: 0,
                        right: 0,
                        width: "1px"
                    }).stop().animate({
                        height: this_.outerHeight()
                    }, 300);
                    this_.find(".rtl").css({
                        bottom: 0,
                        right: 0,
                        height: "1px"
                    }).stop().animate({
                        width: "100%"
                    }, 300);
                    this_.find(".btt").css({
                        bottom: 0,
                        left: 0,
                        width: "1px"
                    }).stop().animate({
                        height: this_.outerHeight()
                    }, 300);
                }
            },
            mouseleave: function () {
                var this_ = $(this);
                if (this_.hasClass("act")) {
                    return false;
                } else {
                    this_.find(".ltr").stop().animate({
                        width: "0px"
                    }, 300, function () {
                        $(this).css("height", "0px");
                    }).css({
                        top: 0,
                        left: 0
                    });
                    this_.find(".ttb").stop().animate({
                        height: "0px"
                    }, 300, function () {
                        $(this).css("width", "0px");
                    }).css({
                        top: 0,
                        right: 0
                    });
                    this_.find(".rtl").stop().animate({
                        width: "0px"
                    }, 300, function () {
                        $(this).css("height", "0px");
                    }).css({
                        bottom: 0,
                        right: 0
                    });
                    this_.find(".btt").stop().animate({
                        height: "0px"
                    }, 300, function () {
                        $(this).css("width", "0px");
                    }).css({
                        bottom: 0,
                        left: 0
                    });
                    setTimeout(function () {
                        this_.find("i").remove();
                    }, 300);
                }

            }
        });
    });

    //右侧文本内容垂直居中
    jQuery.fn.textCenter = function (eles) {
        setTimeout(function () {
            var eleH = $(eles).height();
            $(eles).css("top", (winH - eleH) / 2);
            //console.log(eleH);
        }, 200);
    }


    //窗口重置时需要执行的函数
    $(window).resize(function () {
        leftHeight();
        jQuery.fn.textCenter(".pageOneMain");
        jQuery.fn.textCenter(".pageTwoMain");
        jQuery.fn.textCenter(".pageThreeMain");
        jQuery.fn.textCenter(".pageFourMain");
        jQuery.fn.textCenter(".pageFiveMain");
    });
})(jQuery);
$(document).ready(function () {
    
});
